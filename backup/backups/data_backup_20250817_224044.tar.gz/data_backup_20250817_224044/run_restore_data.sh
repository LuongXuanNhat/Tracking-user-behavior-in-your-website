#/bin/bash
# Auto-generated restore script for Linux
# Usage: ./run_restore_data.sh [container_name] [keyspace_name]

CONTAINER_NAME=${1:-cassandra_node1}
KEYSPACE=${2:-user_behavior_analytics}

echo "Restoring data to container: $CONTAINER_NAME, keyspace: $KEYSPACE"

# Copy schema files to container
docker cp schema/keyspace_schema.cql $CONTAINER_NAME:/tmp/

# First create keyspace and tables
docker exec $CONTAINER_NAME cqlsh -f /tmp/keyspace_schema.cql

# Restore data for each table
if [ -f "data/customers_data.csv" ]; then
    echo "Restoring data for table: customers"
    docker cp "data/customers_data.csv" $CONTAINER_NAME:/tmp/
    docker exec $CONTAINER_NAME cqlsh -e "COPY $KEYSPACE.customers FROM '/tmp/customers_data.csv' WITH HEADER=true;"
    docker exec $CONTAINER_NAME rm -f "/tmp/customers_data.csv"
else
    echo "Warning: Data file for table customers not found"
fi
if [ -f "data/websites_data.csv" ]; then
    echo "Restoring data for table: websites"
    docker cp "data/websites_data.csv" $CONTAINER_NAME:/tmp/
    docker exec $CONTAINER_NAME cqlsh -e "COPY $KEYSPACE.websites FROM '/tmp/websites_data.csv' WITH HEADER=true;"
    docker exec $CONTAINER_NAME rm -f "/tmp/websites_data.csv"
else
    echo "Warning: Data file for table websites not found"
fi
if [ -f "data/events_data.csv" ]; then
    echo "Restoring data for table: events"
    docker cp "data/events_data.csv" $CONTAINER_NAME:/tmp/
    docker exec $CONTAINER_NAME cqlsh -e "COPY $KEYSPACE.events FROM '/tmp/events_data.csv' WITH HEADER=true;"
    docker exec $CONTAINER_NAME rm -f "/tmp/events_data.csv"
else
    echo "Warning: Data file for table events not found"
fi
if [ -f "data/events_by_user_data.csv" ]; then
    echo "Restoring data for table: events_by_user"
    docker cp "data/events_by_user_data.csv" $CONTAINER_NAME:/tmp/
    docker exec $CONTAINER_NAME cqlsh -e "COPY $KEYSPACE.events_by_user FROM '/tmp/events_by_user_data.csv' WITH HEADER=true;"
    docker exec $CONTAINER_NAME rm -f "/tmp/events_by_user_data.csv"
else
    echo "Warning: Data file for table events_by_user not found"
fi
if [ -f "data/events_by_type_data.csv" ]; then
    echo "Restoring data for table: events_by_type"
    docker cp "data/events_by_type_data.csv" $CONTAINER_NAME:/tmp/
    docker exec $CONTAINER_NAME cqlsh -e "COPY $KEYSPACE.events_by_type FROM '/tmp/events_by_type_data.csv' WITH HEADER=true;"
    docker exec $CONTAINER_NAME rm -f "/tmp/events_by_type_data.csv"
else
    echo "Warning: Data file for table events_by_type not found"
fi
if [ -f "data/events_by_session_data.csv" ]; then
    echo "Restoring data for table: events_by_session"
    docker cp "data/events_by_session_data.csv" $CONTAINER_NAME:/tmp/
    docker exec $CONTAINER_NAME cqlsh -e "COPY $KEYSPACE.events_by_session FROM '/tmp/events_by_session_data.csv' WITH HEADER=true;"
    docker exec $CONTAINER_NAME rm -f "/tmp/events_by_session_data.csv"
else
    echo "Warning: Data file for table events_by_session not found"
fi
if [ -f "data/api_key_websites_data.csv" ]; then
    echo "Restoring data for table: api_key_websites"
    docker cp "data/api_key_websites_data.csv" $CONTAINER_NAME:/tmp/
    docker exec $CONTAINER_NAME cqlsh -e "COPY $KEYSPACE.api_key_websites FROM '/tmp/api_key_websites_data.csv' WITH HEADER=true;"
    docker exec $CONTAINER_NAME rm -f "/tmp/api_key_websites_data.csv"
else
    echo "Warning: Data file for table api_key_websites not found"
fi

echo "Data restore completed"
