@echo off
REM Auto-generated restore script
REM Usage: run_restore_data.bat [container_name] [keyspace_name]

set "CONTAINER_NAME=%1"
set "KEYSPACE=%2"
if "%CONTAINER_NAME%"=="" set "CONTAINER_NAME=cassandra_node1"
if "%KEYSPACE%"=="" set "KEYSPACE=user_behavior_analytics"

echo Restoring data to container: %CONTAINER_NAME%, keyspace: %KEYSPACE%

REM First create keyspace and tables
docker exec %CONTAINER_NAME% cqlsh -f /tmp/keyspace_schema.cql

REM Copy schema files to container
docker cp schema\keyspace_schema.cql %CONTAINER_NAME%:/tmp/

REM Restore data for each table
echo Restoring data for table: customers
if exist "data\customers_data.csv" (
    docker cp "data\customers_data.csv" %CONTAINER_NAME%:/tmp/
    docker exec %CONTAINER_NAME% cqlsh -e "COPY %KEYSPACE%.customers FROM '/tmp/customers_data.csv' WITH HEADER=true;"
    docker exec %CONTAINER_NAME% rm -f "/tmp/customers_data.csv"
) else (
    echo Warning: Data file for table customers not found
)
echo Restoring data for table: websites
if exist "data\websites_data.csv" (
    docker cp "data\websites_data.csv" %CONTAINER_NAME%:/tmp/
    docker exec %CONTAINER_NAME% cqlsh -e "COPY %KEYSPACE%.websites FROM '/tmp/websites_data.csv' WITH HEADER=true;"
    docker exec %CONTAINER_NAME% rm -f "/tmp/websites_data.csv"
) else (
    echo Warning: Data file for table websites not found
)
echo Restoring data for table: events
if exist "data\events_data.csv" (
    docker cp "data\events_data.csv" %CONTAINER_NAME%:/tmp/
    docker exec %CONTAINER_NAME% cqlsh -e "COPY %KEYSPACE%.events FROM '/tmp/events_data.csv' WITH HEADER=true;"
    docker exec %CONTAINER_NAME% rm -f "/tmp/events_data.csv"
) else (
    echo Warning: Data file for table events not found
)
echo Restoring data for table: events_by_user
if exist "data\events_by_user_data.csv" (
    docker cp "data\events_by_user_data.csv" %CONTAINER_NAME%:/tmp/
    docker exec %CONTAINER_NAME% cqlsh -e "COPY %KEYSPACE%.events_by_user FROM '/tmp/events_by_user_data.csv' WITH HEADER=true;"
    docker exec %CONTAINER_NAME% rm -f "/tmp/events_by_user_data.csv"
) else (
    echo Warning: Data file for table events_by_user not found
)
echo Restoring data for table: events_by_type
if exist "data\events_by_type_data.csv" (
    docker cp "data\events_by_type_data.csv" %CONTAINER_NAME%:/tmp/
    docker exec %CONTAINER_NAME% cqlsh -e "COPY %KEYSPACE%.events_by_type FROM '/tmp/events_by_type_data.csv' WITH HEADER=true;"
    docker exec %CONTAINER_NAME% rm -f "/tmp/events_by_type_data.csv"
) else (
    echo Warning: Data file for table events_by_type not found
)
echo Restoring data for table: events_by_session
if exist "data\events_by_session_data.csv" (
    docker cp "data\events_by_session_data.csv" %CONTAINER_NAME%:/tmp/
    docker exec %CONTAINER_NAME% cqlsh -e "COPY %KEYSPACE%.events_by_session FROM '/tmp/events_by_session_data.csv' WITH HEADER=true;"
    docker exec %CONTAINER_NAME% rm -f "/tmp/events_by_session_data.csv"
) else (
    echo Warning: Data file for table events_by_session not found
)
echo Restoring data for table: api_key_websites
if exist "data\api_key_websites_data.csv" (
    docker cp "data\api_key_websites_data.csv" %CONTAINER_NAME%:/tmp/
    docker exec %CONTAINER_NAME% cqlsh -e "COPY %KEYSPACE%.api_key_websites FROM '/tmp/api_key_websites_data.csv' WITH HEADER=true;"
    docker exec %CONTAINER_NAME% rm -f "/tmp/api_key_websites_data.csv"
) else (
    echo Warning: Data file for table api_key_websites not found
)

echo Data restore completed
pause
